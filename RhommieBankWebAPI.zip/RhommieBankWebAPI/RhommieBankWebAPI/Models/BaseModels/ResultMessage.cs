﻿namespace Rhommie_Bank_Web_App.Models.BaseModels
{
    public class ResultMessage
    {
        public String meesageType { get; set; }
        public String meesageName { get; set; }
        public long trId { get; set; }

    }
}
