﻿namespace RhommieBankWebAPI.Models.BaseModels
{
    public class BaseModel
    {
        public String created_by { get; set; }
        public String created_at { get; set; }
        public String updated_by { get; set; }
        public String updated_at { get; set; }
    }
}
