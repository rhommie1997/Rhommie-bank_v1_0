﻿using RhommieBankWebAPI.Models.BaseModels;

namespace RhommieBankWebAPI.Models.Persons
{
    public class PersonDto
    {
        public string Name { get; set; }
        public int age { get; set; }

    }
}
