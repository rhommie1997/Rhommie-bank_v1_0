﻿using RhommieBankWebAPI.Models.BaseModels;

namespace RhommieBankWebAPI.Models.Persons
{
    public class Person : BaseModel
    {
        public long Id { get; set; }
        public string Name { get; set; }
        public int age { get; set; }

    }
}
