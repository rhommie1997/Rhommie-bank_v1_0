﻿	select count(1) from(
		select 
		row_number() over (order by id asc) as [row],
		id,
		[name],
		age,
		created_by,
		created_dt
		from person
		where [name] like '%'+@name+'%'
	)tb 