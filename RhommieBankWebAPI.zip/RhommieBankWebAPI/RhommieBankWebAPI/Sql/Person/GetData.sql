﻿select 
		id,
		[name],
		age,
		created_by,
		created_dt
		from person