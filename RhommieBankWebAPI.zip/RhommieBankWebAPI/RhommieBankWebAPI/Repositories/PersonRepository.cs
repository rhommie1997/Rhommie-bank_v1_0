﻿using Rhommie_Bank_Web_App.Models.BaseModels;
using RhommieBankWebAPI.Models.Persons;
using RhommieBankWebAPI.Repositories.Base;
using System.Data.SqlClient;

namespace RhommieBankWebAPI.Repositories
{
    public class PersonRepository : BaseRepository
    {

        public static PersonRepository instance = null;
        public static PersonRepository Instance
        {
            get
            {
                if (instance == null)
                {
                    instance = new PersonRepository();
                }
                return instance;
            }
        }

        public List<Person> getPersons()
        {
            List<Person> peoples = new List<Person>();
            Person people;

            SqlConnection conn = openConnection();
            conn.Open();
            String sql = GetSqlFromDirectory("Sql/Person/GetData.sql");

            SqlCommand comm = new SqlCommand(sql, conn);

            using (SqlDataReader reader = comm.ExecuteReader())
            {
                while (reader.Read())
                {
                    people = new Person();
                    people.Id = reader.GetInt32(0);
                    people.Name = reader.GetString(1);
                    people.age = reader.GetInt32(2);
                    people.created_by = reader.GetString(3);
                    people.created_at = "" + reader.GetDateTime(4);
                    peoples.Add(people);
                }
            }
            return peoples;
        }

        public Person getPersonById(long id)
        {
            Person person = new Person();

            SqlConnection conn = openConnection();
            conn.Open();
            String sql = GetSqlFromDirectory("Sql/Person/GetPersonById.sql");

            SqlCommand comm = new SqlCommand(sql, conn);
            comm.Parameters.AddWithValue("@id", id);

            using (SqlDataReader reader = comm.ExecuteReader())
            {
                if (reader.Read())
                {
                    person.Id = reader.GetInt32(0);
                    person.Name = reader.GetString(1);
                    person.age = reader.GetInt32(2);
                    person.created_by = reader.GetString(3);
                    person.created_at = ""+reader.GetDateTime(4);
                }
            }
                return person;
        }

        public ResultMessage insert(Person person)
        {
            ResultMessage result = new ResultMessage();

            SqlConnection conn = openConnection();
            conn.Open();

            if (person.Name == null)
            {
                result.meesageType = "warning";
                result.meesageName = "Please fill your full name !!";
            }
            else if (person.age < 17)
            {
                result.meesageType = "warning";
                result.meesageName = "Age minimal is 17 !!";
            }
            else
            {
                try
                {
                    String sql = GetSqlFromDirectory("Sql/Person/Insert.sql");
                    SqlCommand comm = new SqlCommand(sql, conn);
                    comm.Parameters.AddWithValue("@name", person.Name);
                    comm.Parameters.AddWithValue("@age", person.age);
                    comm.Parameters.AddWithValue("@created_by", person.created_by);

                    comm.ExecuteNonQuery();

                    result.meesageType = "success";
                    result.meesageName = "Insert Person Success !!";
                }
                catch (Exception e)
                {
                    result.meesageType = "error";
                    result.meesageName = "Error Insert : " + e.Message;
                }
            }


            return result;

        }

        public ResultMessage update(long id, PersonDto person)
        {
            ResultMessage result = new ResultMessage();


            SqlConnection conn = openConnection();
            conn.Open();

            if (person.Name == null)
            {
                result.meesageType = "warning";
                result.meesageName = "Please fill your full name !!";
            }
            else if (person.age < 17)
            {
                result.meesageType = "warning";
                result.meesageName = "Age minimal is 17 !!";
            }
            else
            {
                try
                {
                    String sql = GetSqlFromDirectory("Sql/Person/Update.sql");
                    SqlCommand comm = new SqlCommand(sql, conn);

                    comm.Parameters.AddWithValue("@id", id);
                    comm.Parameters.AddWithValue("@name", person.Name);
                    comm.Parameters.AddWithValue("@age", person.age);
                    comm.ExecuteNonQuery();

                    result.meesageType = "success";
                    result.meesageName = "Update Person Success !!";
                }
                catch (Exception e)
                {
                    result.meesageType = "error";
                    result.meesageName = "Error Update : " + e.Message;
                }
            }
            return result;
        }

        public ResultMessage DeleteOneData(long id)
        {

            SqlConnection conn = openConnection();
            conn.Open();
            ResultMessage result = new ResultMessage();

            try
            {
                String sql = GetSqlFromDirectory("Sql/Person/DeleteOneData.sql");
                SqlCommand comm = new SqlCommand(sql, conn);

                comm.Parameters.AddWithValue("@id", id);

                comm.ExecuteNonQuery();
                result.meesageType = "success";
                result.meesageName = "Delete Data Success !!";

            }
            catch (Exception e)
            {
                result.meesageType = "error";
                result.meesageName = "Error Delete : " + e.Message;
            }

            return result;

        }


    }
}
