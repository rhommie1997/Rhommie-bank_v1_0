﻿using System.Data.SqlClient;


namespace RhommieBankWebAPI.Repositories.Base
{
    public class BaseRepository
    {

        public static string connection = "Data Source=DESKTOP-TJQ5RPI;Initial Catalog=RhommieBank;Integrated Security=True";

        public SqlConnection openConnection()
        {
            SqlConnection sqlConnection = new SqlConnection(connection);
            return sqlConnection;
        }

        public static String GetSqlFromDirectory(String directory)
        {
            String path = System.AppDomain.CurrentDomain.BaseDirectory;

            for (int i = 0; i < 4; i++)
            {
                path = Directory.GetParent(path).FullName;
            }


            path = path + "//" + directory;

            String sql = File.ReadAllText(path);

            return sql;
        }

    }
}
