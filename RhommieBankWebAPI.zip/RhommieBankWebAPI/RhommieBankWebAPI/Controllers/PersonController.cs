﻿using DocumentFormat.OpenXml.Spreadsheet;
using DocumentFormat.OpenXml.Vml.Spreadsheet;
using Microsoft.AspNetCore.Mvc;
using Rhommie_Bank_Web_App.Models.BaseModels;
using RhommieBankWebAPI.Models.Persons;
using RhommieBankWebAPI.Repositories;

namespace RhommieBankWebAPI.Controllers
{
    [ApiController]
    [Route("persons")]
    public class PersonController : ControllerBase
    {

        PersonRepository pr = PersonRepository.Instance;

        //private static readonly List<Person> persons = new()
        //{
        //    new Person(){ 
        //        Id=1,
        //        Name="Rhommie Juliantho",
        //        age=25,
        //        created_by="Users",
        //        created_at=""+DateTimeOffset.UtcNow
        //    },
        //    new Person(){
        //        Id=2,
        //        Name="Amelia Bianca",
        //        age=22,
        //        created_by="Users",
        //        created_at=""+DateTimeOffset.UtcNow
        //    },
        //    new Person(){
        //        Id=3,
        //        Name="Cristiano Ronaldo",
        //        age=37,
        //        created_by="Users",
        //        created_at=""+DateTimeOffset.UtcNow
        //    }
        //};
       
        [HttpGet]
        public IEnumerable<Person> getPersons()
        {
            List<Person> persons = pr.getPersons();
            return persons;
        }

        [HttpGet("{id}")]
        public ActionResult<Person> getPersonsById(long id)
        {
            Person person = pr.getPersonById(id);

            if(person == null)
            {
                return NotFound();
            }

            return person;
        }

        [HttpPost]
        public ActionResult<Person> post(PersonDto createPerson)
        {
        

            Person person = new Person()
            {
                Name = createPerson.Name,
                age = createPerson.age,
                created_by = "Users"
            };

            ResultMessage result = pr.insert(person);

            return Ok(result);
        }

        [HttpPut("{id}")]

        public IActionResult put(long id, PersonDto updatePersonDto)
        {
            ResultMessage result = pr.update(id, updatePersonDto);


            return Ok(result);
        }

        [HttpDelete("{id}")]
        public IActionResult delete(long id)
        {

            ResultMessage result = pr.DeleteOneData(id);

            return Ok(result);
        }

    }


}
